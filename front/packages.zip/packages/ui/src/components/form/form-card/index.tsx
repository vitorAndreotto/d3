import React from 'react';
import { Button } from '../../button';
import { educacao, saude, tecnologia } from '@repo/assets/src/images/form-types';

export interface Form {
  id: string;
  rota: string;
  nome: string;
  tipo: string;
}

interface FormCardProps {
  form: Form;
  onAccess?: (formId: string) => void;
}

export const FormCard: React.FC<FormCardProps> = ({ form, onAccess }) => {
  const getBackgroundImage = () => {
    switch (form.tipo.toLowerCase()) {
      case 'educacao':
        return educacao;
      case 'saude':
        return saude;
      case 'tecnologia':
        return tecnologia;
      default:
        return '';
    }
  };

  return (
    <div className="relative w-full aspect-[2/1] overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-50"
        style={{ 
          backgroundImage: `url(${getBackgroundImage()})`,
          width: '200%',
          left: '-50%'
        }}
      />
      
      {/* Content */}
      <div className="relative h-full border border-[#ffff00] p-6 hover:shadow-lg transition-shadow bg-black/50 backdrop-blur-sm">
        <h3 className="text-xl font-semibold mb-2 text-white">{form.nome}</h3>
        <div className="mt-4">
          <Button onClick={() => onAccess?.(form.id)}>
            Acessar
          </Button>
        </div>
      </div>
    </div>
  );
};

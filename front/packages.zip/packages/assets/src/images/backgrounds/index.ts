export { default as educacao } from './educacao.png';
export { default as saude } from './saude.png';
export { default as tecnologia } from './tecnologia.png';

// Export background videos
export { default as defaultBgVideo } from './esfera.mp4';

// Add more video exports here as needed
// export { default as video2 } from './video2.mp4';
// export { default as video3 } from './video3.mp4';

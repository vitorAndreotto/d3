declare module '@repo/assets/images/*' {
  const value: string;
  export default value;
}

declare module '@repo/assets/videos/*' {
  const value: string;
  export default value;
}

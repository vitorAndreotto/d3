// This file exists to provide proper module resolution
// The actual assets are imported directly from their respective directories
module.exports = {
  // This is intentionally empty as assets are imported directly via path
};

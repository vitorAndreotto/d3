export interface Form {
  id: number;
  name: string;
  createdAt: string;
  active: boolean;
}
